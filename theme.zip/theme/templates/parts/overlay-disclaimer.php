<div id="cookie-disclaimer" class="cookie-disclaimer">
    <div>
      <span><?php echo the_field('cookie_disclaimer','option');?></span>
      <span class="close-disclaimer icons8-delete"></span>
    </div>
</div>
