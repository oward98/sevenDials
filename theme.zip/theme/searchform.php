<!-- search -->
<div class="search-wrapper">
	<form class="search" method="get" action="<?php echo home_url(); ?>" role="search">
		<i class="icons8-search"></i>
		<input class="search-input" type="search" name="s" placeholder="Search">
		<button class="search-submit" type="submit" role="button" hidden></button>
	</form>
</div>
<!-- /search -->
